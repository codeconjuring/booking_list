<!doctype html>
<html lang="en">

<head>
    @include('layouts._head')
</head>

<body>
    @yield('content')


    @include('layouts._script')
</body>

</html>
