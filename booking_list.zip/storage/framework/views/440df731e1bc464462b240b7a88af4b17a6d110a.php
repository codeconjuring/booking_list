<?php $__env->startSection('content'); ?>
<div class="content-wrapper">

    <?php echo $__env->make('admin.layouts._page_header',['title'=>$page_title,'type'=>'List'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(route('admin.form.add-more')); ?>" method="get">
        <?php echo csrf_field(); ?>
    <div class="row">

        <div class="col-md-3">


                <div class="form-group">
                    <label for="">Select Series</label>
                    <select name="series_id" id="" class="form-control">
                        <option value="">Select series</option>
                        <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $series): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($series->id); ?>"><?php echo e($series->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['series_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

          </div>
          <div class="col-md-2">
              <br>
              <button type="submit" class="btn btn-success">Create Another One</button>
          </div>
        </div>
    </form>


      <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title"><?php echo e($page_title); ?></h4>


              <table class="table table-bordered">
                <thead>
                  <tr>
                    
                    <th> Serise </th>
                    <th> No </th>
                    <th> Title</th>
                    <th> LAN </th>
                    <?php $__currentLoopData = $form_builder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$form_bui): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th><?php echo e($form_bui->label); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tr>
                </thead>
                <tbody>
                    <?php
                        $i=1;
                    ?>

                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b=>$book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($book->parent==1): ?>
                    <tr>
                        
                        <td><?php echo e($book->serise->name); ?></td>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($book->title); ?></td>
                        <td><?php echo e($book->language); ?></td>

                        <?php $__currentLoopData = $form_builder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form_bui): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $book->content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bc=>$bookContent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php if($form_bui->id==$bc): ?>
                                            <?php if($bookContent['type']=='1'): ?>
                                                <?php
                                                    $status=App\Models\Status::whereId($bookContent['text'])->first();
                                                ?>
                                            <td style="background:<?php echo e($status?$status->color:''); ?>"><?php echo e($status?$status->status:'N/A'); ?></td>
                                            <?php elseif($bookContent['text']==0): ?>
                                            <td><?php echo e($bookContent['text']); ?></td>
                                            <?php else: ?>
                                            <td>N/A</td>
                                            <?php endif; ?>
                                        <?php else: ?>
                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tr>
                    <?php endif; ?>


                    <?php if(isset($book->childs)): ?>



                                <?php $__currentLoopData = $book->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($child->parent_id!=null): ?>
                                    <tr>
                                        
                                        <td><?php echo e($child->parent_data->serise->name); ?></td>
                                        <td><?php echo e($i++); ?></td>
                                        <td><?php echo e($child->parent_data->title); ?></td>
                                        <td><?php echo e($child->parent_data->language); ?></td>
                                        <?php $__currentLoopData = $form_builder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form_bui): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $child->parent_data->content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bc=>$bookContent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php if($form_bui->id==$bc): ?>
                                                    <?php if($bookContent['type']=='1'): ?>
                                                        <?php
                                                            $status=App\Models\Status::whereId($bookContent['text'])->first();
                                                        ?>
                                                    <td style="background:<?php echo e($status?$status->color:''); ?>"><?php echo e($status?$status->status:'N/A'); ?></td>
                                                    <?php elseif($bookContent['text']==0): ?>
                                                    <td><?php echo e($bookContent['text']); ?></td>
                                                    <?php else: ?>
                                                    <td>N/A</td>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tr>
                                    <?php endif; ?>



                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>


</div>


<?php $__env->stopSection(); ?>









<?php echo $__env->make('admin.layouts._master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\booking_list\resources\views/admin/form/index.blade.php ENDPATH**/ ?>