<?php $__env->startSection('content'); ?>
<div class="content-wrapper">

    <?php echo $__env->make('admin.layouts._page_header',['title'=>$page_title,'type'=>'Form'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="row">
        <div class="col-md-6 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title"><?php echo e($page_title); ?></h4>

              <form class="forms-sample" action="<?php echo e(route('admin.email.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                        <label for="">Host <span class="error">*</span></label>
                        <input type="text" name="contents[host]" class="form-control" placeholder="Enter host here" required value="<?php if($email_setting): ?><?php echo e($email_setting->contents['host']); ?><?php endif; ?>"/>
                    </div>

					<div class="form-group">
                        <label for="">Port <span class="error">*</span></label>
                        <input type="text" name="contents[port]" class="form-control" placeholder="Enter port here" required value="<?php if($email_setting): ?><?php echo e($email_setting->contents['port']); ?><?php endif; ?>"/>
                    </div>

					<div class="form-group">
                        <label for="">Encryption</label>
                        <input type="text" name="contents[encryption]" class="form-control" placeholder="Enter encryption here" value="<?php if($email_setting): ?><?php echo e($email_setting->contents['encryption']); ?><?php endif; ?>"/>
                    </div>

					<div class="form-group">
                        <label for="">Username <span class="error">*</span></label>
                        <input type="text" name="contents[username]" class="form-control" placeholder="Enter username here" required value="<?php if($email_setting): ?><?php echo e($email_setting->contents['username']); ?><?php endif; ?>"/>
                    </div>

					<div class="form-group">
                        <label for="">Password <span class="error">*</span></label>
                        <input type="text" name="contents[password]" class="form-control" placeholder="Enter password here" required value="<?php if($email_setting): ?><?php echo e($email_setting->contents['password']); ?><?php endif; ?>"/>
                    </div>

					<div class="form-group">
                        <label for="">Mail From name <span class="error">*</span></label>
                        <input type="text" name="contents[from_name]" class="form-control" placeholder="Enter from name here" required value="<?php if($email_setting): ?><?php echo e($email_setting->contents['from_name'] ?? ''); ?><?php endif; ?>"/>
                    </div>

					<div class="form-group">
                        <label for="">Mail From address <span class="error">*</span></label>
                        <input type="text" name="contents[from_address]" class="form-control" placeholder="Enter from address here" required value="<?php if($email_setting): ?><?php echo e($email_setting->contents['from_address']); ?><?php endif; ?>"/>
                    </div>


                <button type="submit" class="btn btn-gradient-primary mr-2">Update Email Setting</button>
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-light">Back</a>
              </form>
            </div>
          </div>
        </div>



      </div>


</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts._master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\booking_list\resources\views/admin/email/create.blade.php ENDPATH**/ ?>