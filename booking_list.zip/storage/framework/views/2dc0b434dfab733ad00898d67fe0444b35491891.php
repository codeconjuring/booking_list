<!DOCTYPE html>
<html lang="en">
  <head>
    <?php echo $__env->make('admin.layouts._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
    <div class="container-scroller">

      <?php echo $__env->make('admin.layouts._top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="container-fluid page-body-wrapper">

            <?php echo $__env->make('admin.layouts._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="main-panel">

                <?php echo $__env->yieldContent('content'); ?>


                <?php echo $__env->make('admin.layouts._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
      </div>


    </div>

    <?php echo $__env->make('admin.layouts._script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html>
<?php /**PATH E:\xampp\htdocs\booking_list\resources\views/admin/layouts/_master.blade.php ENDPATH**/ ?>