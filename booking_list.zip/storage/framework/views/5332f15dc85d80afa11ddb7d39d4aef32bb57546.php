   <!-- JAVASCRIPT -->
   <script src="<?php echo e(asset('dashboard/update_assets/libs/jquery/jquery.min.js')); ?>"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
   <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
   <script src="<?php echo e(asset('dashboard/update_assets/libs/metismenu/metisMenu.min.js')); ?>"></script>
   <script src="<?php echo e(asset('dashboard/update_assets/libs/simplebar/simplebar.min.js')); ?>"></script>
   <script src="<?php echo e(asset('dashboard/update_assets/libs/node-waves/waves.min.js')); ?>"></script>
   <script src="<?php echo e(asset('dashboard/update_assets/libs/feather-icons/feather.min.js')); ?>"></script>
   <!-- pace js -->
   <script src="<?php echo e(asset('dashboard/update_assets/libs/pace-js/pace.min.js')); ?>"></script>

   <!-- Required datatable js -->
   <script src="<?php echo e(asset('dashboard/update_assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
   <script src="<?php echo e(asset('dashboard/update_assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
   <!-- Buttons examples -->
   <script src="<?php echo e(asset('dashboard/update_assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
   <script src="<?php echo e(asset('dashboard/update_assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')); ?>"></script>
   <script src="<?php echo e(asset('dashboard/update_assets/libs/jszip/jszip.min.js')); ?>"></script>
   <script src="<?php echo e(asset('dashboard/update_assets/libs/pdfmake/build/pdfmake.min.js')); ?>"></script>
   <script src="<?php echo e(asset('dashboard/update_assets/libs/pdfmake/build/vfs_fonts.js')); ?>"></script>
   <script src="<?php echo e(asset('dashboard/update_assets/libs/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script>
   <script src="<?php echo e(asset('dashboard/update_assets/libs/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
   <script src="<?php echo e(asset('dashboard/update_assets/libs/datatables.net-buttons/js/buttons.colVis.min.js')); ?>"></script>

   <!-- Responsive examples -->
   <script src="<?php echo e(asset('dashboard/update_assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
   <script src="<?php echo e(asset('dashboard/update_assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>"></script>


   <!-- Datatable init js -->
   <script src="<?php echo e(asset('dashboard/update_assets/libs/select2/js/select2.min.js')); ?>"></script>
   <script src="<?php echo e(asset('dashboard/update_assets/js/pages/select2.init.js')); ?>"></script>
   <!-- dropzone js -->
   <script src="<?php echo e(asset('dashboard/update_assets/libs/dropzone/min/dropzone.min.js')); ?>"></script>

   <!-- apexcharts -->
   <script src="<?php echo e(asset('dashboard/update_assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
   <script src="<?php echo e(asset('dashboard/update_assets/libs/raphael.min.js')); ?>"></script>
   <script src="<?php echo e(asset('dashboard/update_assets/libs/morris.min.js')); ?>"></script>
   <script src="<?php echo e(asset('dashboard/update_assets/js/pages/morris.init.js')); ?>"></script>
   
   <!-- dashboard init -->
   <script src="<?php echo e(asset('dashboard/update_assets/js/app.js')); ?>"></script>



<script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<?php echo $__env->yieldContent('js'); ?>

<?php echo $__env->yieldContent('script'); ?>

<script>

    // Toster notification
    <?php if(Session::has('success')): ?>
        toastr["success"]("<?php echo e(Session::get('success')); ?>")
    <?php elseif(Session::has('error')): ?>
        toastr["error"]("<?php echo e(Session::get('error')); ?>")
    <?php endif; ?>

    // Sweet alear
    function logout()
    {
        Swal.fire({
            title: 'Are you sure?',
            text: "Logout the system!!!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Logout it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.assign('/logout')
                }
            })
    }

    function makeDeleteRequest(event,id)
    {
        Swal.fire({
            title: 'Are you sure?',
            text: "Delete This!!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $(`#deleteForm${id}`).submit();
                }
            })
    }

</script>




<?php /**PATH E:\laragon\www\booking_list\resources\views/admin/layout/_script.blade.php ENDPATH**/ ?>