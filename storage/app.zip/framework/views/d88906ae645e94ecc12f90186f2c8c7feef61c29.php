<div data-simplebar class="h-100">
    <!--- Sidemenu -->
    <div id="sidebar-menu">
        <!-- LOGO -->
        <div class="navbar-brand-box">

            <?php if(Settings::get('site_logo')): ?>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="logo logo-dark">
                    <span class="logo-sm">
                        <img src="<?php echo e(asset('dashboard/update_assets/images/sort-logo.png')); ?>" alt="<?php echo e(Settings::get('title')); ?>">
                    </span>
                    <span class="logo-lg">
                        <img src="<?php echo e(asset(Storage::url(Settings::get('site_logo')))); ?>" alt="<?php echo e(Settings::get('title')); ?>">
                    </span>
                </a>

                <a href="<?php echo e(route('admin.dashboard')); ?>" class="logo logo-light">
                    <span class="logo-sm">
                        <img src="<?php echo e(asset('dashboard/update_assets/images/sort-logo.png')); ?>" alt="<?php echo e(Settings::get('title')); ?>">
                    </span>
                    <span class="logo-lg">
                        <img src="<?php echo e(asset(Storage::url(Settings::get('site_logo')))); ?>" alt="<?php echo e(Settings::get('title')); ?>">
                    </span>
                </a>
            <?php else: ?>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="logo logo-dark">
                    <span class="logo-sm">
                        <img src="<?php echo e(asset('dashboard/update_assets/images/sort-logo.png')); ?>" alt="<?php echo e(Settings::get('title')); ?>">
                    </span>
                    <span class="logo-lg">
                        <img src="<?php echo e(asset(Storage::url(Settings::get('site_logo')))); ?>" alt="<?php echo e(Settings::get('title')); ?>">
                    </span>
                </a>

                <a href="<?php echo e(route('admin.dashboard')); ?>" class="logo logo-light">
                    <span class="logo-sm">
                        <img src="<?php echo e(asset('dashboard/update_assets/images/sort-logo.png')); ?>" alt="<?php echo e(Settings::get('title')); ?>">
                    </span>
                    <span class="logo-lg">
                        <img src="<?php echo e(asset(config('settings.site_logo'))); ?>" alt="<?php echo e(Settings::get('title')); ?>">
                    </span>
                </a>
            <?php endif; ?>
        </div>
        <!-- Left Menu Start -->
        <ul class="metismenu list-unstyled" id="side-menu">
            <li>
                <a href="javascript: void(0);" class="has-arrow" aria-expanded="true">
                    <i class="icon-dashboard"></i>
                    <span data-key="t-dashboard">Dashboard</span>
                </a>
                <ul class="sub-menu mm-collapse" aria-expanded="false">
                    <li><a href="<?php echo e(route('admin.dashboard')); ?>">General Progress</a></li>
                    <li><a href="#">Book Details</a></li>
                    <li><a href="#">Sales & Distribution</a></li>
                </ul>
            </li>

            <li>
                <a href="javascript: void(0);" class="has-arrow">
                    <i class="icon-book-plus"></i>
                    <span>Book Management</span>
                </a>
                <ul class="sub-menu" aria-expanded="false">
                    <li><a href="<?php echo e(route('admin.form.index')); ?>">Book List</a></li>
                    <li><a href="<?php echo e(route('admin.form.create')); ?>">Book Creation</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript: void(0);" class="has-arrow">
                    <i class="icon-book-open"></i>
                    <span>Book Attributes</span>
                </a>
                <ul class="sub-menu" aria-expanded="false">
                    <li><a href="<?php echo e(route('admin.form-builder.index')); ?>">Book Format</a></li>
                    <li><a href="<?php echo e(route('admin.series.index')); ?>">Book Series</a></li>
                    <li><a href="<?php echo e(route('admin.status.index')); ?>">Book Status</a></li>
                    <li><a href="<?php echo e(route('admin.category.index')); ?>">Book Tags</a></li>
                    <li><a href="<?php echo e(route('admin.author.index')); ?>">Book Author</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript: void(0);" class="has-arrow">
                     <i class="fas fa-cog"></i>
                    <span>Sales/Distribution</span>
                </a>
                <ul class="sub-menu" aria-expanded="false">
                    <li><a href="#">Production Report</a></li>
                    <li><a href="#">Distribution Report</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript: void(0);" class="has-arrow">
                    <i class="icon-user"></i>
                    <span>Administration</span>
                </a>
                <ul class="sub-menu" aria-expanded="true">
                    <li>
                        <a href="javascript: void(0);" class="has-arrow">User</a>
                        <ul class="sub-menu" aria-expanded="true">
                            <li><a href="<?php echo e(route('admin.user.index')); ?>">User List</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow">Role</a>
                        <ul class="sub-menu" aria-expanded="true">
                            <li><a href="<?php echo e(route('admin.role.create')); ?>">Create Role</a></li>
                            <li><a href="<?php echo e(route('admin.role.index')); ?>">List Roles</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow">Setting</a>
                        <ul class="sub-menu" aria-expanded="true">
                            <li><a href="<?php echo e(route('admin.setting.index')); ?>">System Setting</a></li>
                            <li><a href="<?php echo e(route('admin.email.index')); ?>">Email Setting</a></li>
                        </ul>
                    </li>

                </ul>
            </li>
        </ul>

    </div>
    <!-- Sidebar -->
</div>
<?php /**PATH G:\xampp\htdocs\ztfbookfiverr\resources\views/admin/layout/_sidebar.blade.php ENDPATH**/ ?>