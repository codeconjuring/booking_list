

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.css"/>
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.1.0/css/buttons.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="page-content">
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0 font-size-18"><?php echo e($page_title); ?></h4>
                    <div class="page-title-right">
                        <div class="page-title-right">
                            <a href="<?php echo e(route('admin.form.create')); ?>" class="btn btn-primary"><i data-feather="plus"></i> Create Book</a>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- end page title -->

    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-6">
                            <h2>Filter Book List</h2>
                        </div>

                        <div class="col-md-6">
                            <button class="btn btn-primary btn-sm float-right" type="button" onclick="getFilter()" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                                <i class="fas fa-filter"></i>
                            </button>
                        </div>
                    </div>


                </div>


                    <div class="collapse" id="collapseExample">
                        <div class="card-body">
                            <form action="" method="get" class="form-group">

                                <?php echo csrf_field(); ?>

                                <div class="row">
                                    <div class="col-md-3">
                                        <label for="">Select Series</label>
                                        <select name="series_ids[]" id="" class="form-control select2" multiple>
                                            <option value="">Select Series</option>
                                            <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$ser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e(in_array($ser->id,$select_series)?"selected":""); ?> value="<?php echo e($ser->id); ?>"><?php echo e($ser->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-3">
                                        <label for="">Select Languages</label>
                                        <select name="language[]" id="" class="form-control select2" multiple>
                                            <option value="">Select Series</option>
                                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$lan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e(in_array($lan->language,$select_language)?"selected":""); ?> value="<?php echo e($lan->language); ?>"><?php echo e($lan->language); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-3">
                                        <label for="">Select Status</label>
                                        <select name="status_ids[]" id="" class="form-control select2" multiple>
                                            <option value="">Select Status</option>
                                            <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e(in_array($sta->id,$select_status)?"selected":""); ?> value="<?php echo e($sta->id); ?>"><?php echo e($sta->status); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-3">
                                        <label for="">ZTF?</label>
                                        <select name="ztf[]" id="" class="form-control select2" multiple>
                                            <option value="">Select ZTF</option>
                                            <?php $__currentLoopData = $ztf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e(in_array($key,$select_ztf)?'selected':""); ?> value="<?php echo e($key); ?>"><?php echo e($val); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-4 mt-2">
                                        <button type="submit" class="btn btn-info btn-sm">Search</button>
                                    </div>

                                </div>

                            </form>
                        </div>
                </div>


            </div>
        </div>
    </div>
    <br>
    <!-- container-fluid -->

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">

                    <table cellpadding="2" class="cc-datatable table nowrap w-100" id="myTable">
                        <thead>
                          <tr>
                            <th class="text-center d-none">  </th>
                            <th class="text-center"> Series </th>
                            <th class="text-center"> No </th>
                            <th class="text-center"> Author </th>
                            <th class="text-center"> ZTF?</th>
                            <th class="text-center"> Tags </th>
                            <th class="text-center"> Title</th>
                            <th class="text-center"> LAN </th>
                            <?php $__currentLoopData = $form_builder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$form_bui): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="text-center"><?php echo e($form_bui->label); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Edit Book Management','Delete Book Management','Add Another Translation Book Management'])): ?>
                            <th class="text-center">Action</th>
                            <?php endif; ?>
                          </tr>
                        </thead>
                        <tbody>
                            <?php
                                $book_i=1;
                                $row_count=0;
                            ?>
                            <?php $__currentLoopData = $getSeriyes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$getSeriye): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $entry=App\Models\Book::whereCategoryId($getSeriye->category_id)->get();

                                    $series_wise_titles=App\Models\BookList::whereCategoryId($getSeriye->category_id)->get();
                                    $books_count=count($series_wise_titles);
                                    $series_flag=0;
                                ?>

                                <?php $__currentLoopData = $entry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <?php
                                        $query=App\Models\BookList::query();
                                        if(count($select_language)){
                                            $query->whereIn('language',$select_language)->whereBookId($e->id);
                                        }else{
                                            $query->whereBookId($e->id);
                                        }

                                        if(count($select_ztf)>0){
                                            $query->whereIn('available',$select_ztf);
                                        }



                                        $books=$query->get();

                                        $entry_count=count($books);
                                        $entry_flag=0;
                                        $main_title_flag=0;
                                    ?>

                                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b=>$book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                        <?php if($filter_data!=1): ?>
                                            <?php if(($main_title_flag==1) && ($entry_id!=$e->id)): ?>
                                                <?php break; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>


                                        <?php if($row_show!=0 && $row_count>=$row_show): ?>
                                            <?php break; ?>
                                        <?php endif; ?>

                                        <?php
                                            $categories='';
                                            $more_tags = '';
                                            $tag_count = 0;
                                            foreach($book->categories as $cat){
                                                if(!empty($cat->category)){
                                                    if($tag_count == 1)
                                                    {
                                                        $more_tags = $categories.'<br/><span class="badge badge-primary mr-1">'.$cat->category->name.'</span>';
                                                    }
                                                    else if($tag_count > 1)
                                                    {
                                                        $more_tags.='<br/><span class="badge badge-primary mr-1">'.$cat->category->name.'</span>';
                                                    }
                                                    else
                                                    {
                                                        $categories.='<span class="badge badge-primary mr-1">'.$cat->category->name.'</span>';
                                                    }
                                                    $tag_count += 1;
                                                }
                                            }
                                        ?>
                                        <tr class="tableAddTitles<?php echo e($e->id); ?>">
                                            <td class="d-none">-</td>
                                            <?php if($series_flag==0): ?>
                                                <td class="text-center"><?php echo e($book->serise->name); ?></td>
                                                <?php
                                                    $series_flag=1;
                                                ?>

                                            <?php else: ?>
                                                <td class="text-center"></td>
                                            <?php endif; ?>

                                            <?php if($entry_flag==0): ?>
                                                <td class="text-center"><?php echo e($book_i++); ?></td>
                                                <?php
                                                    $entry_flag=1;
                                                ?>
                                            <?php else: ?>
                                            <td class="text-center"></td>
                                            <?php endif; ?>

                                            <td class="text-center"><?php echo e($book->author); ?></td>

                                            <td class="text-center"><?php echo $book->available_status; ?></td>


                                            <td>
                                                <?php if($tag_count <= 1): ?>
                                                    <span><?php echo $categories; ?>

                                                    </span>
                                                <?php else: ?>
                                                    <span id="spanmore<?php echo e($book->id); ?>">
                                                        <?php echo $categories; ?>

                                                        <small><a class="text-dark" onclick="tag_span(1,<?php echo e($book->id); ?>)" href="javascript:void(0)">More</a></small>
                                                    </span>
                                                    <span class="d-none" id="spanless<?php echo e($book->id); ?>">
                                                        <?php echo $more_tags; ?>

                                                        <small><a class="text-dark" onclick="tag_span(0,<?php echo e($book->id); ?>)"data-tag-span-id="spanmore<?php echo e($book->id); ?>" href="javascript:void(0)">Less</a></small>
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <?php if(($main_title_flag==0) && ($filter_data!=1)): ?>
                                            <td class="<?php echo e($entry_id==$e->id?'bg-primary':''); ?>"><b><a style="text-decoration: none; color:black" data-flag="0" id="mainTitle<?php echo e($e->id); ?>" onclick="showMoreTitle('<?php echo e($e->id); ?>','<?php echo e($book_i); ?>',$(this).attr('data-flag'))" href="javascript:void(0)"><?php echo e($book->title); ?> (<?php echo e($entry_count); ?>)</a><img width="10%"  class="buffering-img<?php echo e($e->id); ?> d-none" src="<?php echo e(asset('dashboard/assets/images/loading-buffering.gif')); ?>" alt=""></b></td>
                                            <?php else: ?>
                                            <td class="<?php echo e($entry_id==$e->id?'bg-primary':''); ?>"><?php echo e($book->title); ?></td>
                                            <?php endif; ?>

                                            <td class="text-center"><?php echo e($book->language); ?></td>



                                            <?php
                                                $count_form_builder=count($form_builder);
                                                $book_content_count=count($book->content);
                                                $result=$count_form_builder-$book_content_count;
                                            ?>
                                            <?php $__currentLoopData = $form_builder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form_bui): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(array_key_exists($form_bui->id,$book->content)): ?>
                                                    <?php if($book->content[$form_bui->id]['type']=="1"): ?>
                                                    <?php
                                                                $query=App\Models\Status::query();
                                                                if(count($select_status)>0){
                                                                    $query->whereIn('id',$select_status)->whereId($book->content[$form_bui->id]['text']);
                                                                }else{
                                                                    $query->whereId($book->content[$form_bui->id]['text']);
                                                                }
                                                                $color=$query->first();
                                                    ?>

                                                    <td class="text-center" style="background:<?php echo e($color?$color->color:""); ?>"><?php echo e($status_array[$book->content[$form_bui->id]['text']]??'-'); ?></td>
                                                    <?php else: ?>
                                                    <td class="text-center"><?php echo e($book->content[$form_bui->id]['text']); ?> </td>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <td class="text-center">-</td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td class="text-center">

                                                <div class="dropdown">
                                                    <a class="btn cc-table-action p-0 dropdown-toggle" href="#"
                                                        id="dropdownMenuButton" data-toggle="dropdown"
                                                        aria-expanded="false">
                                                        <i class="fas fa-ellipsis-v"></i>
                                                    </a>

                                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">

                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Add Another Translation Book Management')): ?>
                                                        <li><a class="dropdown-item <?php echo e($book->add_another_book_translation==1?'d-none':''); ?>" href="<?php echo e(route('admin.form.add-another-title',['id'=>$book->id])); ?>"><i class="mdi mdi-google-translate"></i> Add Translation</a></li>
                                                        <?php endif; ?>

                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Edit Book Management')): ?>
                                                        <li><a class="dropdown-item" href="<?php echo e(route('admin.form.edit',$book->id)); ?>"><i class="fas fa-edit"></i> Edit</a></li>
                                                        <?php endif; ?>

                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Delete Book Management')): ?>
                                                        <form action="<?php echo e(route('admin.form.destroy',$book->id)); ?>" id="deleteForm<?php echo e($book->id); ?>"  method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('delete'); ?>
                                                        </form>
                                                    <?php
                                                        $translations_count = 2;
                                                    ?>
                                                    <?php if($book->add_another_book_translation == 0): ?>
                                                    <?php
                                                        $translations_count = App\Models\BookList::whereBookId($book->book_id)->count();
                                                    ?>
                                                    <?php endif; ?>
                                                    <?php if($translations_count > 1 && $book->add_another_book_translation == 0): ?>
                                                        <li><a class="dropdown-item text-danger" href="#" onclick="prompt('You need to delete the translations of this title before deleting it!')"><i class="fas fa-trash-alt text-danger"></i> Delete</a></li>
                                                    <?php else: ?>
                                                        <li><a class="dropdown-item text-danger" href="#" onclick="makeDeleteRequest(this,<?php echo e($book->id); ?>)"><i class="fas fa-trash-alt text-danger"></i> Delete</a></li>
                                                    <?php endif; ?>
                                                    <?php endif; ?>
                                                    </ul>
                                                </div>

                                            </td>
                                        </tr>
                                                <?php
                                                    $row_count+=1;
                                                ?>

                                                <?php
                                                    if($main_title_flag==0){
                                                        $main_title_flag=1;
                                                    }
                                                ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                </div>
            </div>
        </div>
    </div>
</div>



<div class="modal" id="myModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Filter and export report and PDF</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <form action="<?php echo e(route('admin.form.download')); ?>" method="GET">
                <?php echo csrf_field(); ?>

            <?php $__currentLoopData = $form_builder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$form_bui): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="checkbox" name="select_row[]" id="inputlabel<?php echo e($form_bui->id); ?>" value="<?php echo e($form_bui->id); ?>">
                <label for="inputlabel<?php echo e($form_bui->id); ?>"><?php echo e($form_bui->label); ?></label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="form-group">
                <label for="">Select Series</label>
                <select name="series[]" id="" class="form-control select2" multiple>
                    <?php $__currentLoopData = $get_all_series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $get_all_ser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($get_all_ser->id); ?>"><?php echo e($get_all_ser->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="">Select Tags</label>
                <select name="tag_ids[]" id="" class="form-control select2" multiple>
                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="">Select Language</label>
                <select name="languages[]" id="" class="form-control select2" multiple>
                    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($language->language); ?>"><?php echo e($language->language); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="">Select Status</label>
                <select name="status_ids[]" id="" class="form-control select2" multiple>
                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sta->id); ?>"><?php echo e($sta->status); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="">ZTF?</label>
                <select name="ztf[]" id="" class="form-control select2" multiple>
                    <option value="">Select ZTF</option>
                    <?php $__currentLoopData = $ztf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e(in_array($key,$select_ztf)?'selected':""); ?> value="<?php echo e($key); ?>"><?php echo e($val); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Download Report</button>

            </form>
        </div>
        <div class="modal-footer">
        </div>
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.12/datatables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.1.0/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.1.0/js/buttons.print.min.js"></script>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    var mytable="";
    $(document).ready( function () {


    // $('#myTable').dataTable({
    //     dom: 'Bfrtip',
    //     buttons: [
    //         {
    //             text: 'Create',
    //             action: function ( e, dt, node, config ) {
    //                 window.location =""
    //             }
    //         },
    //         'copy',
    //         'csv',
    //         'excel',
    //         'pdf',
    //         'print',

    //     ],
    //     language: {
    //         paginate: {
    //         next: '<i class="icon-right-arrow"></i>',
    //         previous: '<i class="icon-left-arrow"></i>',
    //         },
    //         searchPlaceholder: "Search",
    //         search: '<i class="fas fa-search"></i>',
    //     },
    //     });

    // $(".dataTable").wrap('<div class="table-responsive"><div>');

        var table = $('#myTable').DataTable({
        dom: '<"toolbar">lBftip',
        buttons:
        [

            {
            text: 'Download Report',
                action: function ( e, dt, node, config ) {
                    downloadReport()
                }
            },
            {
            text: 'Create',
                action: function ( e, dt, node, config ) {
                    window.location ="<?php echo e(route('admin.form.create')); ?>"
                }
            },
            'copy',
            'csv',
            'excel',
            'print',
            {
                extend: 'pdf',
                text: 'pdf',
                orientation: 'landscape',
                pageSize: 'LEGAL',
                exportOptions: {
                    columns: [ -1, ':visible' ]
                }
            }
        ]
    });

    $('.dataTable').wrap('<div class="table-responsive"></div>');

    // $("div.toolbar").html('<b class="float-right mt-1">Download As: &nbsp; </b>');

    // table.buttons().container().appendTo($('#printbar'));
    // table.buttons().container().appendTo('#datatable-buttons_wrapper .col-md-6:eq(0)');


});



function showMoreTitle(e_id,book_i,data_attr)
{

    // console.log($(`#mainTitle${e_id}`).attr('data-flag'));


    $(`.buffering-img${e_id}`).removeClass('d-none');

    if(data_attr=='0')
    {

        $.ajax({
        url:"<?php echo e(route('form.show-more-title')); ?>",
        method:"GET",
        data:{'e_id':e_id,'book_i':book_i},
        success:(response)=>{
            $(`.tableAddTitles${e_id}`).after(response.view);
            $(`.buffering-img${e_id}`).addClass('d-none');
            $(`#mainTitle${e_id}`).attr('data-flag',1);
            $('#myTable').DataTable();

        },
        error:(error)=>{
            console.log(error);
        }

      });
    }else{
        $(`.buffering-img${e_id}`).addClass('d-none');
        $(`.subTitle${e_id}`).remove();
        $(`#mainTitle${e_id}`).attr('data-flag',0);
    }


    // let baseUrl=window.location.origin;
    // let scroll=$(window).scrollTop();
    // window.location.replace(baseUrl+'/admin/form?e_id='+e_id+'&book_i='+book_i+"&scroll="+scroll);

    //
}

function downloadReport(){
    $('#myModal').modal('show');
    $('.select2').select2();

}
// Filter Colaps
function getFilter()
{
    console.log('abcd');
    $('.select2').select2();
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout._master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\ztfbookfiverr\resources\views/admin/form/index.blade.php ENDPATH**/ ?>