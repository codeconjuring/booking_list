<?php $__env->startSection('content'); ?>

<div class="page-content">
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0 font-size-18"><?php echo e($page_title); ?></h4>
                </div>
            </div>
        </div>
        <!-- end page title -->

    </div>
    <!-- container-fluid -->

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-10 m-auto">

                            <form action="<?php echo e(route('admin.role.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label for="#">Role Name</label>
                                    <div class="position-relative">
                                        <input type="text" name="role_name" class="form-control" placeholder="Type role name" required>
                                    </div>
                                </div>


                                <div class="cc-permission-all mt-4 ">
                                    <div class="d-flex align-items-cnter">
                                        <h4 class="d-flex">All Permissions</h4>
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" name="parent_id" class="custom-control-input" id="customCheck-all" value="all">
                                            <label class="custom-control-label" for="customCheck-all"></label>
                                        </div>
                                    </div>



                                        <div class="cc-permission-inner mt-4">
                                            <div class="accordion" id="accordionExample">
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="card">
                                                        <div class="card-header d-flex align-items-center justify-content-between" id="heading<?php echo e($permission->id); ?>">
                                                            <p class="mb-0"><?php echo e($permission->name); ?> All</p>

                                                            <div class="custom-control custom-switch">
                                                                <input type="checkbox" name="parent_id" class="custom-control-input" id="customSwitch<?php echo e($permission->id); ?>" onchange="loadChildren(<?php echo e($permission->id); ?>)" data-toggle="collapse" data-target="#collapse<?php echo e($permission->id); ?>" aria-expanded="false" aria-controls="collapseOne">
                                                                <label class="custom-control-label" for="customSwitch<?php echo e($permission->id); ?>"></label>
                                                            </div>
                                                        </div>
                                                        <?php $__currentLoopData = $permission->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div id="collapse<?php echo e($permission->id); ?>" class="collapse ic_parent-<?php echo e($permission->id); ?>" aria-labelledby="heading<?php echo e($permission->id); ?>" data-parent="#accordionExample">
                                                            <div class="card-body">
                                                                <ul class="cc-permission-under">
                                                                    <li class="d-flex align-items-center justify-content-between">
                                                                        <p class="mb-0"><?php echo e($children->name); ?></p>
                                                                        <div class="custom-control custom-switch">
                                                                            <input type="checkbox" name="permissions[]" class="custom-control-input parent-identy-<?php echo e($permission->id); ?>" id="customSwitch<?php echo e($children->id); ?>" value="<?php echo e($children->id); ?>">
                                                                            <label class="custom-control-label" for="customSwitch<?php echo e($children->id); ?>"></label>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>


                                </div>
                                <div class="cc-button-heads mt-5 text-center">
                                    <button class="btn btn-primary">Create Role</button>
                                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-light">Back</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
        $("#customCheck-all").click(function(){
            $('input:checkbox').not(this).prop('checked', this.checked);
            // $('div .ic_div-show').toggle();
            $('div .collapse').toggle();
        });

        function loadChildren(parent_id) {

            $(`#ic_parent-${parent_id}`).toggle();

            if ($(`#customSwitch${parent_id}`).is(':checked')){
                $(`.parent-identy-${parent_id}`).each(function(){
                    $(this).prop('checked', true);
                });
            }else{
                $(`.parent-identy-${parent_id}`).each(function(){
                    $(this).prop('checked', false);
                });
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
	<style>
        .ic_parent_permission {
            background-color: rgb(250, 243, 213);
            color: rgb(220, 74, 83);
            border-radius: 5px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout._master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\booking_list\resources\views/admin/role/create.blade.php ENDPATH**/ ?>