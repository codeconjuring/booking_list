<meta charset="utf-8" />
<title><?php echo e(Settings::get('title')??"ztfbooks"); ?> | <?php echo e($page_title??''); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
<meta content="themessani" name="author" />
<!-- App favicon -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php if(Settings::get('favicon')): ?>
    <link rel="shortcut icon" href="<?php echo e(asset(Storage::url(Settings::get('favicon')))); ?>" />
<?php else: ?>
    <link rel="shortcut icon" href="<?php echo e(asset(config('settings.favicon'))); ?>" />
<?php endif; ?>

<!-- preloader css -->
<link rel="stylesheet" href="<?php echo e(asset('dashboard/update_assets/css/preloader.min.css')); ?>" type="text/css" />
<!-- DataTables -->
<link href="<?php echo e(asset('dashboard/update_assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('dashboard/update_assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />

<!-- Bootstrap Css -->
<link href="<?php echo e(asset('dashboard/update_assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('dashboard/update_assets/icomoon/icon-moons.css')); ?>" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="<?php echo e(asset('dashboard/update_assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />


<link href="<?php echo e(asset('dashboard/update_assets/libs/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('dasboard/update_assets/libs/dropzone/min/dropzone.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('dashboard/update_assets/libs/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />


<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">

<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<!-- App Css-->
<link href="<?php echo e(asset('dashboard/update_assets/css/style.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('dashboard/update_assets/css/custome.css')); ?>" rel="stylesheet" type="text/css" />



<?php echo $__env->yieldContent('css'); ?>
<?php /**PATH E:\laragon\www\booking_list\resources\views/admin/layout/_head.blade.php ENDPATH**/ ?>