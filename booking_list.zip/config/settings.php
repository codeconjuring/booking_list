<?php

return
    [

    "title"           => "ztfbooks",
    "site_logo"       => "dashboard/assets/images/logo.svg",
    "favicon"         => "dashboard/assets/images/favicon.ico",
    "default_profile" => "dashboard/assets/images/faces/face1.jpg",
];
