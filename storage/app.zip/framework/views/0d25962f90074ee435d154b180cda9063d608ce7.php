<div class="page-header">
    <h3 class="page-title"> <?php echo e($title??'System Settings'); ?> </h3>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#"><?php echo e($title??'System Settings'); ?></a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($type??'Form'); ?></li>
      </ol>
    </nav>
</div>
<?php /**PATH G:\xampp\htdocs\ztfbookfiverr\resources\views/admin/layouts/_page_header.blade.php ENDPATH**/ ?>