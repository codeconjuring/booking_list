<meta charset="utf-8" />
<title>Books 4 revival</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
<meta content="themessani" name="author" />
<!-- App favicon -->
<link rel="shortcut icon" href="<?php echo e(asset('dashboard/update_assets/images/favicon.ico')); ?>">

<!-- preloader css -->
<link rel="stylesheet" href="<?php echo e(asset('dashboard/update_assets/css/preloader.min.css')); ?>" type="text/css" />

<!-- Bootstrap Css -->
<link href="<?php echo e(asset('dashboard/update_assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('dashboard/update_assets/icomoon/icon-moons.css')); ?>" rel="stylesheet" type="text/css" />
<!-- DataTables -->
<link href="<?php echo e(asset('dashboard/update_assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('dashboard/update_assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />


<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<!-- Icons Css -->
<link href="<?php echo e(asset('dashboard/update_assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="<?php echo e(asset('dashboard/update_assets/css/style.css')); ?>" rel="stylesheet" type="text/css" />


<?php /**PATH G:\xampp\htdocs\ztfbookfiverr\resources\views/layouts/_head.blade.php ENDPATH**/ ?>