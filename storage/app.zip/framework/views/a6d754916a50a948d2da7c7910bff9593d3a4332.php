  <!-- JAVASCRIPT -->
  <script src="<?php echo e(asset('dashboard/assets/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <script src="<?php echo e(asset('dashboard/update_assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo e(asset('dashboard/update_assets/libs/metismenu/metisMenu.min.js')); ?>"></script>
  <script src="<?php echo e(asset('dashboard/update_assets/libs/simplebar/simplebar.min.js')); ?>"></script>
  <script src="<?php echo e(asset('dashboard/update_assets/libs/node-waves/waves.min.js')); ?>"></script>
  <script src="<?php echo e(asset('dashboard/update_assets/libs/feather-icons/feather.min.js')); ?>"></script>
  <!-- pace js -->
  <script src="<?php echo e(asset('dashboard/update_assets/libs/pace-js/pace.min.js')); ?>"></script>

  <!-- Required datatable js -->
  <script src="<?php echo e(asset('dashboard/update_assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('dashboard/update_assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
  
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

  <!-- Responsive examples -->
  <script src="<?php echo e(asset('dashboard/update_assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
  <script src="<?php echo e(asset('dashboard/update_assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>"></script>



  <!-- apexcharts -->
  <script src="<?php echo e(asset('dashboard/update_assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
  <!-- dashboard init -->
  <script src="<?php echo e(asset('dashboard/update_assets/js/app.js')); ?>"></script>
   <!-- Datatable init js -->
   <!--<script src="<?php echo e(asset('dashboard/update_assets/js/pages/datatables.init.js')); ?>"></script>-->
   <?php echo $__env->yieldContent('js'); ?>
<?php /**PATH G:\xampp\htdocs\ztfbookfiverr\resources\views/layouts/_script.blade.php ENDPATH**/ ?>