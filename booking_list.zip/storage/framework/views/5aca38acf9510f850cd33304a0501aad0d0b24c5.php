<?php $__env->startSection('content'); ?>
<div class="content-wrapper">

    <?php echo $__env->make('admin.layouts._page_header',['title'=>$page_title,'type'=>'Form'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="row">
        <div class="col-md-6 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title"><?php echo e($page_title); ?></h4>
              <form class="forms-sample" action="<?php echo e(route('admin.form-builder.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                  <label for="exampleInputUsername1">Label</label><span class="text-danger">*</span>
                  <input type="text" name="label" value="<?php echo e(old('label')); ?>" class="form-control" id="exampleInputUsername1" placeholder="Label">

                  <?php $__errorArgs = ['label'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="exampleInputUsername1">Select Type</label><span class="text-danger">*</span>
                    <p>Dropdown <input type="radio" checked name="type" value="1"> Text <input type="radio" name="type" value="0"></p>

                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <button type="submit" class="btn btn-gradient-primary mr-2">Create</button>
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-light">Back</a>
              </form>
            </div>
          </div>
        </div>


      </div>


</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts._master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\booking_list\resources\views/admin/form-builder/create.blade.php ENDPATH**/ ?>