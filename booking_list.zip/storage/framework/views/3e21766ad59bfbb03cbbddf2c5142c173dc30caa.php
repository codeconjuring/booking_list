<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title><?php echo e(Settings::get('title')??"ztfbooks"); ?> | <?php echo e($page_title??''); ?></title>
<link rel="stylesheet" href="<?php echo e(asset('dashboard/assets/vendors/mdi/css/materialdesignicons.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dashboard/assets/vendors/css/vendor.bundle.base.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dashboard/assets/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dashboard/assets/css/custome.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dashboard/assets/css/speedometer.css')); ?>">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php if(Settings::get('favicon')): ?>
    <link rel="shortcut icon" href="<?php echo e(asset(Storage::url(Settings::get('favicon')))); ?>" />
<?php else: ?>
    <link rel="shortcut icon" href="<?php echo e(asset(config('settings.favicon'))); ?>" />
<?php endif; ?>

<?php echo $__env->yieldContent('css'); ?>



<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">

<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>

<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php /**PATH E:\laragon\www\booking_list\resources\views/admin/layouts/_head.blade.php ENDPATH**/ ?>