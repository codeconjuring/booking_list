

<?php $__env->startSection('content'); ?>
    <!-- Begin page -->
    <div id="layout-wrapper">
        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="content">
            <div class="page-content">
                <div class="container-fluid">
                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">

                            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                <?php if(Settings::get('site_logo')): ?>
                                <a class="navbar-brand brand-logo" href="<?php echo e(route('admin.dashboard')); ?>"><img width="10%" src="<?php echo e(asset(Storage::url(Settings::get('site_logo')))); ?>" alt="<?php echo e(Settings::get('title')); ?>" /></a>
                                <?php else: ?>
                                    <a class="navbar-brand brand-logo" href="<?php echo e(route('admin.dashboard')); ?>"><img width="10%" src="<?php echo e(asset(config('settings.site_logo'))); ?>" alt="<?php echo e(Settings::get('title')); ?>" /></a>
                                <?php endif; ?>
                                <div class="page-title-right">
                                    <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">System Login</a>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!-- end page title -->

                </div>
                <!-- container-fluid -->

                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="cc-table-button-heads align-items-center d-flex justify-content-between">
                                    <ul class="list-unstyled d-flex ic-tables-buttons">
                                        <li>
                                            <button onclick="downloadReport()" class="btn tb-btn btn-outline-primary"><i class="icon-download"></i>Download Report</button>
                                        </li>
                                    </ul>
                                </div>
                                <table id="datatable"  class="dataTable table nowrap w-100">
                                    <thead>
                                        <tr>

                                            <th class="text-center d-none">Action</th>

                                            <th class="text-center"> Series </th>
                                            <th class="text-center"> No </th>
                                            <th class="text-center"> Author </th>
                                            
                                            
                                            <th class="text-center"> Title</th>
                                            <th class="text-center"> LAN </th>
                                            <?php $__currentLoopData = $form_builder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$form_bui): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($form_bui->label!='GFP'): ?>
                                                <th class="text-center"><?php echo e($form_bui->label); ?></th>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    </thead>

                                    <tbody>

                                        <?php
                                            $book_i=1;
                                            $row_count=0;
                                            ?>
                                            <?php $__currentLoopData = $getSeriyes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$getSeriye): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $entry=App\Models\Book::whereCategoryId($getSeriye->category_id)->get();

                                                    $series_wise_titles=App\Models\BookList::whereCategoryId($getSeriye->category_id)->get();
                                                    $books_count=count($series_wise_titles);
                                                    $series_flag=0;

                                                ?>

                                                <?php $__currentLoopData = $entry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <?php
                                                        $query=App\Models\BookList::query();
                                                        if(count($select_language)){
                                                            $query->whereIn('language',$select_language)->whereBookId($e->id);
                                                        }else{
                                                            $query->whereBookId($e->id);
                                                        }

                                                        if(count($select_ztf)>0){
                                                            $query->whereIn('available',$select_ztf);
                                                        }



                                                        $books=$query->get();


                                                        $entry_count=count($books);
                                                        $entry_flag=0;
                                                        $main_title_flag=0;
                                                    ?>

                                                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b=>$book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                                        <?php if($filter_data!=1): ?>
                                                            <?php if(($main_title_flag==1) && ($entry_id!=$e->id)): ?>
                                                                <?php break; ?>
                                                            <?php endif; ?>
                                                        <?php endif; ?>


                                                        <?php if($row_show!=0 && $row_count>=$row_show): ?>
                                                            <?php break; ?>
                                                        <?php endif; ?>

                                                        
                                                        <tr class="tableAddTitles<?php echo e($e->id); ?>">

                                                            <td class="text-center d-none">
                                                                <div class="dropdown">
                                                                    <a class="btn cc-table-action p-0 dropdown-toggle" href="#"
                                                                        role="button" id="dropdownMenuLink" data-bs-toggle="dropdown"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-ellipsis-v"></i>
                                                                    </a>

                                                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                                        <li><a class="dropdown-item" href="#"><i class="mdi mdi-google-translate
                                                                            "></i> Add Translation</a></li>
                                                                        <li><a class="dropdown-item" href="#"><i class="fas fa-edit
                                                                            "></i> Edit</a></li>
                                                                        <li><a class="dropdown-item text-danger" href="#"><i
                                                                                    class="fas fa-trash-alt text-danger"></i> Delete</a>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </td>

                                                            <?php if($series_flag==0): ?>
                                                                <td class="text-center"><?php echo e($book->serise->name); ?></td>
                                                                <?php
                                                                    $series_flag=1;
                                                                ?>

                                                            <?php else: ?>
                                                            <td class="text-center"></td>
                                                            <?php endif; ?>

                                                            <?php if($entry_flag==0): ?>
                                                                <td class="text-center"><?php echo e($book_i++); ?></td>
                                                                <?php
                                                                    $entry_flag=1;
                                                                ?>
                                                            <?php else: ?>
                                                            <td class="text-center"></td>
                                                            <?php endif; ?>

                                                            <td class="text-center"><?php echo e($book->author); ?></td>

                                                            


                                                            
                                                            <?php if(($main_title_flag==0) && ($filter_data!=1)): ?>
                                                            <td class="<?php echo e($entry_id==$e->id?'bg-primary':''); ?>"><b><a style="text-decoration: none; color:black" data-flag="0" id="mainTitle<?php echo e($e->id); ?>" onclick="showMoreTitle('<?php echo e($e->id); ?>','<?php echo e($book_i); ?>',$(this).attr('data-flag'))" href="javascript:void(0)"><?php echo e($book->title); ?> (<?php echo e($entry_count); ?>)</a><img width="10%" class="buffering-img<?php echo e($e->id); ?> d-none" src="<?php echo e(asset('dashboard/assets/images/loading-buffering.gif')); ?>" alt=""></b></td>
                                                            <?php else: ?>
                                                            <td class="<?php echo e($entry_id==$e->id?'bg-primary':''); ?>"><?php echo e($book->title); ?></td>
                                                            <?php endif; ?>

                                                            <td class="text-center"><?php echo e($book->language); ?></td>
                                                            <?php
                                                                $count_form_builder=count($form_builder);
                                                                $book_content_count=count($book->content);
                                                                $result=$count_form_builder-$book_content_count;
                                                            ?>
                                                            <?php $__currentLoopData = $form_builder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form_bui): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($form_bui->label!='GFP'): ?>
                                                                    <?php if(array_key_exists($form_bui->id,$book->content)): ?>
                                                                        <?php if($book->content[$form_bui->id]['type']=="1"): ?>
                                                                        <?php
                                                                                    $query=App\Models\Status::query();
                                                                                    if(count($select_status)>0){
                                                                                        $query->whereIn('id',$select_status)->whereId($book->content[$form_bui->id]['text']);
                                                                                    }else{
                                                                                        $query->whereId($book->content[$form_bui->id]['text']);
                                                                                    }
                                                                                    $color=$query->first();
                                                                        ?>

                                                                        <td class="text-center" style="background:<?php echo e($color?$color->color:""); ?>"><?php echo e($status_array[$book->content[$form_bui->id]['text']]??'-'); ?></td>
                                                                        <?php else: ?>
                                                                        <td class="text-center"><?php echo e($book->content[$form_bui->id]['text']); ?> </td>
                                                                        <?php endif; ?>
                                                                    <?php else: ?>
                                                                        <td class="text-center">-</td>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tr>
                                                                <?php
                                                                    $row_count+=1;
                                                                ?>

                                                                <?php
                                                                    if($main_title_flag==0){
                                                                        $main_title_flag=1;
                                                                    }
                                                                ?>

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>


        

        <div class="modal fade" id="myModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="staticBackdropLabel">Filter and export report and PDF</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('form.download')); ?>" method="GET">
                        <?php echo csrf_field(); ?>

                    <?php $__currentLoopData = $form_builder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$form_bui): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="checkbox" name="select_row[]" id="inputlabel<?php echo e($form_bui->id); ?>" value="<?php echo e($form_bui->id); ?>">
                        <label for="inputlabel<?php echo e($form_bui->id); ?>"><?php echo e($form_bui->label); ?></label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="form-group">
                        <label for="">Select Series</label>
                        <select name="series[]" id="" class="form-control select2" multiple>
                            <?php $__currentLoopData = $get_all_series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $get_all_ser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($get_all_ser->id); ?>"><?php echo e($get_all_ser->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="">Select Tags</label>
                        <select name="tag_ids[]" id="" class="form-control select2" multiple>
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="">Select Language</label>
                        <select name="languages[]" id="" class="form-control select2" multiple>
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($language->language); ?>"><?php echo e($language->language); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Select Status</label>
                        <select name="status_ids[]" id="" class="form-control select2" multiple>
                            <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sta->id); ?>"><?php echo e($sta->status); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">ZTF?</label>
                        <select name="ztf[]" id="" class="form-control select2" multiple>
                            <option value="">Select ZTF</option>
                            <?php $__currentLoopData = $ztf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(in_array($key,$select_ztf)?'selected':""); ?> value="<?php echo e($key); ?>"><?php echo e($val); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Download Report</button>

                    </form>
                </div>
              </div>
            </div>
          </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function () {
        $("#datatable").DataTable();
        $(".dataTable").wrap('<div class="table-responsive"><div>');
    });

function showMoreTitle(e_id,book_i,data_attr)
{

    // console.log($(`#mainTitle${e_id}`).attr('data-flag'));


    $(`.buffering-img${e_id}`).removeClass('d-none');

    if(data_attr=='0')
    {

        $.ajax({
        url:"<?php echo e(route('form.show-more-title')); ?>",
        method:"GET",
        data:{'e_id':e_id,'book_i':book_i,'frontend_request':1},
        success:(response)=>{
            $(`.tableAddTitles${e_id}`).after(response.view);
            $(`.buffering-img${e_id}`).addClass('d-none');
            $(`#mainTitle${e_id}`).attr('data-flag',1);
            // $('.cc-datatable').DataTable();

        },
        error:(error)=>{
            console.log(error);
        }

      });
    }else{
        $(`.buffering-img${e_id}`).addClass('d-none');
        $(`.subTitle${e_id}`).remove();
        $(`#mainTitle${e_id}`).attr('data-flag',0);
    }


    // let baseUrl=window.location.origin;
    // let scroll=$(window).scrollTop();
    // window.location.replace(baseUrl+'/admin/form?e_id='+e_id+'&book_i='+book_i+"&scroll="+scroll);

    //
}

function downloadReport(){
    console.log('abcd');
    $('#myModal').modal('show');
    $('.select2').select2();

}
// Filter Colaps
function getFilter()
{
    $('.select2').select2();
}

// Col spand
// <?php if($entry_id!=0): ?>
// $(document).ready( function () {
//     window.history.pushState({}, document.title, "/" + "admin/form");
// });
// <?php endif; ?>


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts._master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\ztfbookfiverr\resources\views/update_welcome.blade.php ENDPATH**/ ?>