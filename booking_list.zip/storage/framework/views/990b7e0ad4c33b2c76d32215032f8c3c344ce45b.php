<?php $__currentLoopData = $getBookLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$getBookList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<tr class="subTitle<?php echo e($getBookList->book_id); ?>">
    <td class="<?php echo e($frontend_request==1?'d-none':""); ?> text-center">

        <div class="dropdown">
            <a class="btn cc-table-action p-0 dropdown-toggle" href="#"
                id="dropdownMenuButton" data-toggle="dropdown"
                aria-expanded="false">
                <i class="fas fa-ellipsis-v"></i>
            </a>

            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Edit Book Management')): ?>
                <li><a class="dropdown-item" href="<?php echo e(route('admin.form.edit',$getBookList->id)); ?>"><i class="fas fa-edit"></i> Edit</a></li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Delete Book Management')): ?>
                <form action="<?php echo e(route('admin.form.destroy',$getBookList->id)); ?>" id="deleteForm<?php echo e($getBookList->id); ?>"  method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                </form>

                <li><a class="dropdown-item text-danger" href="#" nclick="makeDeleteRequest(this,<?php echo e($getBookList->id); ?>)"><i class="fas fa-trash-alt text-danger"></i> Delete</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </td>

    <td class="text-center"></td>



    <td class="text-center"></td>


    <td class="text-center"><?php echo e($getBookList->author); ?></td>

    <td class="text-center <?php echo e($frontend_request==1?'d-none':""); ?>"><?php echo $getBookList->available_status; ?></td>

    <?php
        $categories='';
        foreach($getBookList->categories as $cat){
            if($cat->category){
                $categories.='<span class="badge bg-primary mr-1">'.$cat->category->name.'</span>&nbsp;';
            }
        }
    ?>
    <td class="<?php echo e($frontend_request==1?'d-none':""); ?>"><?php echo $categories; ?></td>

    <td class=""><?php echo e($getBookList->title); ?></td>

    <td class="text-center"><?php echo e($getBookList->language); ?></td>
    <?php
        $count_form_builder=count($form_builder);
        $book_content_count=count($getBookList->content);
        $result=$count_form_builder-$book_content_count;
    ?>
    <?php $__currentLoopData = $form_builder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form_bui): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if(($frontend_request==1)): ?>

            <?php if($form_bui->label!='GFP'): ?>

                <?php if(array_key_exists($form_bui->id,$getBookList->content)): ?>
                    <?php if($getBookList->content[$form_bui->id]['type']=="1"): ?>

                    <?php
                        $color=App\Models\Status::whereId($getBookList->content[$form_bui->id]['text'])->first();
                    ?>

                    <td class="text-center" style="background:<?php echo e($color?$color->color:""); ?>"><?php echo e($status_array[$getBookList->content[$form_bui->id]['text']]??'-'); ?></td>
                    <?php else: ?>
                    <td class="text-center"><?php echo e($getBookList->content[$form_bui->id]['text']); ?> </td>
                    <?php endif; ?>
                <?php else: ?>
                    <td class="text-center">-</td>
                <?php endif; ?>

            <?php endif; ?>

        <?php else: ?>
            <?php if(array_key_exists($form_bui->id,$getBookList->content)): ?>
                <?php if($getBookList->content[$form_bui->id]['type']=="1"): ?>
                <?php
                    $color=App\Models\Status::whereId($getBookList->content[$form_bui->id]['text'])->first();
                ?>

                <td class="text-center" style="background:<?php echo e($color?$color->color:""); ?>"><?php echo e($status_array[$getBookList->content[$form_bui->id]['text']]??'-'); ?></td>
                <?php else: ?>
                <td class="text-center"><?php echo e($getBookList->content[$form_bui->id]['text']); ?> </td>
                <?php endif; ?>
            <?php else: ?>
                <td class="text-center">-</td>
            <?php endif; ?>
        <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH E:\laragon\www\booking_list\resources\views/admin/form/more_title.blade.php ENDPATH**/ ?>