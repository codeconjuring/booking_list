<div class="page-header">
    <h3 class="page-title"> {{ $title??'System Settings' }} </h3>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">{{ $title??'System Settings' }}</a></li>
        <li class="breadcrumb-item active" aria-current="page">{{ $type??'Form' }}</li>
      </ol>
    </nav>
</div>
