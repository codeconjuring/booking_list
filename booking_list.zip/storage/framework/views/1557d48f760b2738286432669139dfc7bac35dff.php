<?php $__env->startSection('content'); ?>



<div class="content-wrapper">

    <?php echo $__env->make('admin.layouts._page_header',['title'=>$page_title,'type'=>'Form'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title"><?php echo e($page_title); ?></h4>
              <form class="forms-sample" action="<?php echo e(route('admin.role.update',[$role->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="ic_role_name">Role Name</label>
                            <input type="text" class="form-control ic_custom-form-input" id="ic_role_name" autocomplete="off" name="role_name" placeholder="Enter Role Name" required value="<?php echo e($role->name); ?>">
                        </div>

                        <div class="row my-2">
                            <div class="col-8 pt-1">
                                <div class="custom-control" style="padding-left: 0px;">
                                    <label for="customCheck-all">All Permissions</label>
                                </div>
                            </div>
                            <div class="col-4 pt-1">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" name="parent_id" class="custom-control-input" id="customCheck-all" value="all">
                                    <label class="custom-control-label" for="customCheck-all"></label>
                                </div>
                            </div>
                        </div>

                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							             <div class="row ic_parent_permission my-2">
							                 <div class="col-8 pt-1">
							                     <div class="custom-control" style="padding-left: 0px">
							                         <label for="customCheck-<?php echo e($permission->id); ?>"><strong><?php echo e($permission->name); ?> All</strong></label>
							                     </div>
							                 </div>
							                 <div class="col-4 pt-1">
							                     <div class="custom-control custom-checkbox">
							                         <input type="checkbox" name="parent_id" class="custom-control-input" id="customCheck-<?php echo e($permission->id); ?>" onchange="loadChildren(<?php echo e($permission->id); ?>)">
							                         <label class="custom-control-label" for="customCheck-<?php echo e($permission->id); ?>"></label>
							                     </div>
							                 </div>
							             </div>
							             <div class="row ic_div-show" id="ic_parent-<?php echo e($permission->id); ?>" style="display: none;transition: all 10s ease">
							                 <?php $__currentLoopData = $permission->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							                     <div class="col-8 pt-1">
							                         <div class="custom-control" style="padding-left: 0px">
							                             <label for="customCheck-<?php echo e($children->id); ?>"><?php echo e($children->name); ?></label>
							                         </div>
							                     </div>
							                     <div class="col-4 pt-1">
							                         <div class="custom-control custom-checkbox">
							                             <input type="checkbox" <?php echo e(in_array($children->id,$role_permission)?'checked':''); ?> name="permissions[]" class="custom-control-input parent-identy-<?php echo e($permission->id); ?>" id="customCheck-<?php echo e($children->id); ?>" value="<?php echo e($children->id); ?>">
							                             <label class="custom-control-label" for="customCheck-<?php echo e($children->id); ?>"></label>
							                         </div>
							                     </div>
							                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							             </div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        <button type="submit" class="btn btn-gradient-primary mr-2">Update Role</button>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-light">Back</a>
                    </div>

              </form>

            </div>
          </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
        $("#customCheck-all").click(function(){
            $('input:checkbox').not(this).prop('checked', this.checked);
            $('div .ic_div-show').show();
        });

        function loadChildren(parent_id) {

            $(`#ic_parent-${parent_id}`).toggle();

            if ($(`#customCheck-${parent_id}`).is(':checked')){
                $(`.parent-identy-${parent_id}`).each(function(){
                    $(this).prop('checked', true);
                });
            }else{
                $(`.parent-identy-${parent_id}`).each(function(){
                    $(this).prop('checked', false);
                });
            }
        }

        <?php $__currentLoopData = $parents_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            $('#customCheck-<?php echo e($parent_id); ?>').prop('checked', true);
            $(`#ic_parent-<?php echo e($parent_id); ?>`).show();
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
	<style>
        .ic_parent_permission {
            background-color: rgb(250, 243, 213);
            color: rgb(220, 74, 83);
            border-radius: 5px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts._master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\booking_list\resources\views/admin/role/edit.blade.php ENDPATH**/ ?>