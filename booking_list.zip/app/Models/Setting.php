<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Robiussani152\Settings\Models\Settings;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Setting extends Settings
{
    use HasFactory;

    
}
