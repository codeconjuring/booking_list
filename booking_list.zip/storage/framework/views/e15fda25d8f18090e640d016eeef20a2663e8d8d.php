<?php $__env->startSection('content'); ?>


    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18"><?php echo e($page_title); ?></h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

        </div>
        <!-- container-fluid -->

        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-10 m-auto">

                                <form class="forms-sample" action="<?php echo e(route('admin.setting.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>

                                    <div class="form-group">
                                      <label for="exampleInputUsername1">Title</label>
                                      <input type="text" name="title" value="<?php echo e(Settings::get('title')); ?>" class="form-control" id="exampleInputUsername1" placeholder="System Title">
                                      <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputUsername1">Email Notification Email</label>
                                        <input type="email" name="email_notification" value="<?php echo e(Settings::get('email_notification')); ?>" class="form-control" id="exampleInputUsername1" placeholder="Email Notification Email">
                                        <?php $__errorArgs = ['email_notification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                          <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      </div>

                                    <div class="form-group">
                                        <label for="exampleInputUsername1">Report Font Size</label>
                                        <input type="number" name="report_font_size" value="<?php echo e(Settings::get('report_font_size')); ?>" class="form-control" id="exampleInputUsername1" placeholder="Report Font Size">
                                        <?php $__errorArgs = ['report_font_size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                          <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      </div>

                                    <div class="form-group">
                                        <label for="exampleInputUsername1">Site Logo</label> &nbsp;<span class="text-danger">(140X28) px</span>
                                        <div class="input-group">
                                            <span class="input-group-btn">
                                            <a id="siteLogo" data-input="thumbnail" data-preview="holder" class="btn btn-info">
                                                <i class="fa fa-picture-o"></i> Choose
                                            </a>
                                            </span>
                                            <input id="thumbnail" class="form-control" type="text"  name="site_logo">
                                        </div>
                                    </div>


                                    <div class="form-group">
                                        <label for="exampleInputUsername1">Favicon</label> &nbsp;<span class="text-danger">(16X16) px</span>
                                        <div class="input-group">
                                            <span class="input-group-btn">
                                            <a id="faviconBtn" data-input="favicon" data-preview="holder" class="btn btn-info">
                                                <i class="fa fa-picture-o"></i> Choose
                                            </a>
                                            </span>
                                            <input id="favicon" class="form-control" type="text"  name="favicon">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputUsername1">Default profile</label> &nbsp;<span class="text-danger">(32X32) px</span>
                                        <div class="input-group">
                                            <span class="input-group-btn">
                                            <a id="defaultProfilePicBtn" data-input="default_profile_pic" data-preview="holder" class="btn btn-info">
                                                <i class="fa fa-picture-o"></i> Choose
                                            </a>
                                            </span>
                                            <input id="default_profile_pic" class="form-control" type="text"  name="default_profile">
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-primary mr-2">Submit</button>
                                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-light">Back</a>

                                  </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-md-6">
                <div class="card">
                  <div class="card-body">
                    <div class="form-group">
                        <label for="">Site Logo</label><br>
                        <img width="50%" src="<?php echo e(asset(Storage::url(Settings::get('site_logo')))); ?>" alt="">
                    </div>

                    <div class="form-group">
                        <label for="">Favicon</label><br>
                        <img width="50%" src="<?php echo e(asset(Storage::url(Settings::get('favicon')))); ?>" alt="">
                    </div>

                    <div class="form-group">
                        <label for="">Default profile</label><br>
                        <img width="50%" src="<?php echo e(asset(Storage::url(Settings::get('default_profile')))); ?>" alt="">
                    </div>

                  </div>
                </div>
             </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>

<script>
    $('#defaultProfilePicBtn').filemanager('profile');
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout._master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\booking_list\resources\views/admin/setting/index.blade.php ENDPATH**/ ?>