// (function ($) {
//   "use strict";

//   Morris.Donut({
//     element: "morris_donught",
//     data: [
//       { label: "Friends", value: 30 },
//       { label: "Allies", value: 15 },
//       { label: "Enemies", value: 45 },
//       { label: "Neutral", value: 10 },
//     ],
//     resize: true,
//     redraw: true,
//     colors: ["#461EE7", "rgb(30, 170, 231)", "#2BC155"],
//     //responsive:true,
//   });
// })(jQuery);
