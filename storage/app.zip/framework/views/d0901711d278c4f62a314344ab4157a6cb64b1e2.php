<footer class="footer">
    <div class="container-fluid clearfix">
      <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © <a target="_blank" href="http://codeconjuring.com/">Codeconjuring.com</a> 2021</span>
      <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center"> Hungry to develop more</span>
    </div>
  </footer>
<?php /**PATH G:\xampp\htdocs\ztfbookfiverr\resources\views/admin/layouts/_footer.blade.php ENDPATH**/ ?>