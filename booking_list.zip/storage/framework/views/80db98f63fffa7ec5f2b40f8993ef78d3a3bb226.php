<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">

      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
          <span class="menu-title">Dashboard</span>
          <i class="mdi mdi-home menu-icon"></i>
        </a>
      </li>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Add User','Edit User','Show User','Delete User'])): ?>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#ui-form-user" aria-expanded="false" aria-controls="ui-form-user">
          <span class="menu-title">User</span>
          <i class="menu-arrow"></i>
          <i class="mdi mdi-account menu-icon"></i>
        </a>
        <div class="collapse" id="ui-form-user">
          <ul class="nav flex-column sub-menu">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Show User')): ?>
                <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admin.user.index')); ?>">User List</a></li>
            <?php endif; ?>
          </ul>
        </div>
      </li>
      <?php endif; ?>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Add Book Attributes Format','Edit Book Attributes Format','Show Book Attributes Format','Delete Book Attributes Format','Add Book Attributes Series','Edit Book Attributes Series','Show Book Attributes Series','Delete Book Attributes Series','Add Book Attributes Status','Edit Book Attributes Status','Show Book Attributes Status','Delete Book Attributes Status'])): ?>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#ui-form" aria-expanded="false" aria-controls="ui-form">
          <span class="menu-title">Book Attributes</span>
          <i class="menu-arrow"></i>
          <i class="mdi mdi-book-open-variant menu-icon"></i>
        </a>
        <div class="collapse" id="ui-form">
          <ul class="nav flex-column sub-menu">

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Add Book Attributes Format','Edit Book Attributes Format','Show Book Attributes Format','Delete Book Attributes Format'])): ?>
                <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admin.form-builder.index')); ?>">Book Format</a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Add Book Attributes Series','Edit Book Attributes Series','Show Book Attributes Series','Delete Book Attributes Series'])): ?>
            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admin.series.index')); ?>">Book Series</a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Add Book Attributes Status','Edit Book Attributes Status','Show Book Attributes Status','Delete Book Attributes Status'])): ?>
            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admin.status.index')); ?>">Book Status</a></li>
            <?php endif; ?>

            
            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admin.category.index')); ?>">Book Tags</a></li>
            
            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admin.author.index')); ?>">Book Authors</a></li>

          </ul>
        </div>
      </li>
      <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Add Book Management','Edit Book Management','Show Book Management','Delete Book Management','Add Another Translation Book Management','Download Report Book Management'])): ?>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#ui-form1" aria-expanded="false" aria-controls="ui-form1">
          <span class="menu-title">Book Management</span>
          <i class="menu-arrow"></i>
          <i class="mdi mdi-book-open-page-variant menu-icon"></i>
        </a>
        <div class="collapse" id="ui-form1">
          <ul class="nav flex-column sub-menu">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Add Book Management')): ?>
                <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admin.form.create')); ?>">Book Creation</a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Edit Book Management','Show Book Management','Delete Book Management','Add Another Translation Book Management','Download Report Book Management'])): ?>
                <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admin.form.index')); ?>">Book Listing</a></li>
            <?php endif; ?>
          </ul>
        </div>
      </li>
    <?php endif; ?>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Add Administration','Edit Administration','Show Administration','Delete Administration'])): ?>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#ui-role" aria-expanded="false" aria-controls="ui-role">
          <span class="menu-title">Administration</span>
          <i class="menu-arrow"></i>
          <i class="mdi mdi-account-check menu-icon"></i>
        </a>
        <div class="collapse" id="ui-role">
          <ul class="nav flex-column sub-menu">
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Add Administration')): ?>
            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admin.role.create')); ?>">Create Role</a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Show Administration')): ?>
            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admin.role.index')); ?>">List Roles</a></li>
            <?php endif; ?>
          </ul>
        </div>
      </li>
      <?php endif; ?>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['System Settings','Email Settings'])): ?>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
          <span class="menu-title">Settings</span>
          <i class="menu-arrow"></i>
          <i class="mdi mdi-settings menu-icon"></i>
        </a>
        <div class="collapse" id="ui-basic">
          <ul class="nav flex-column sub-menu">
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('System Settings')): ?>
            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admin.setting.index')); ?>">System Setting</a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Email Settings')): ?>
            <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('admin.email.index')); ?>">Email Setting</a></li>
            <?php endif; ?>
          </ul>
        </div>
      </li>
      <?php endif; ?>
    </ul>
  </nav>
<?php /**PATH E:\laragon\www\booking_list\resources\views/admin/layouts/_sidebar.blade.php ENDPATH**/ ?>