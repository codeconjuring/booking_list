<?php $__env->startSection('content'); ?>


    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18"><?php echo e($page_title); ?></h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

        </div>
        <!-- container-fluid -->

        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-10 m-auto">
                                <form class="forms-sample" action="<?php echo e(route('admin.form-builder.store')); ?>" method="POST" autocomplete="off">
                                    <?php echo csrf_field(); ?>


                                    <div class="form-group">
                                        <label for="exampleInputUsername1">Label</label><span class="text-danger">*</span>
                                        <div class="position-relative">
                                            <input type="text" name="label" value="<?php echo e(old('label')); ?>" class="form-control" id="exampleInputUsername1" placeholder="Label" >
                                        </div>


                                        <?php $__errorArgs = ['label'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                          <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      </div>

                                      <div class="form-group">
                                          <label for="exampleInputUsername1">Select Type</label><span class="text-danger">*</span>
                                          <div class="position-relative">
                                            <p>Dropdown <input type="radio" checked name="type" value="1"> Text <input type="radio" name="type" value="0"></p>
                                          </div>

                                          <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                              <span class="text-danger"><?php echo e($message); ?></span>
                                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      </div>


                                      <div class="cc-button-heads mt-5 text-center">
                                        <button type="submit" class="btn btn-primary mr-2">Create</button>
                                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-light">Back</a>
                                    </div>

                                  </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout._master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\booking_list\resources\views/admin/form-builder/create.blade.php ENDPATH**/ ?>